import type { CheckResult } from "../check-result.ts";
import type { WorkerPolicy } from "../policy/workers.ts";

/** The closed adapter-id set, importable without pulling any provider code. */
export const ADAPTER_IDS = ["pi", "claude", "codex"] as const;

/** Agent CLIs supported by orch. */
export type AdapterId = (typeof ADAPTER_IDS)[number];

export function isAdapterId(value: unknown): value is AdapterId {
  return typeof value === "string" && (ADAPTER_IDS as readonly string[]).includes(value);
}

/** Ways an adapter can deliver a mid-run steering message. */
export type SteerMechanism = "inbox" | "keys" | "resume" | "none";

/** Session-lifecycle verbs an adapter may declare a native mechanism for. */
export type LifecycleVerb = "reset" | "reload" | "restart";

/** States an adapter may expose through orch's presence protocol. */
export type AgentState = "idle" | "working" | "blocked" | "done" | "error" | "aborted" | "exited" | "unknown";

/** Inputs shared by interactive and detached spawn commands. */
export interface SpawnOpts {
  /** Presence key to associate with the spawned session, when already allocated. */
  readonly key?: string;
  /** Working directory in which the agent CLI must start. */
  readonly cwd?: string;
  /** Model specification selected for the session, when supported. */
  readonly model?: string;
  /** Directory containing orch's presence protocol files. */
  readonly orchDir?: string;
  /** Additional environment values required by the adapter process. */
  readonly env?: Readonly<Record<string, string>>;
  /** Explicit worker tool allowlist, when the launcher applies one. */
  readonly tools?: string;
  /** What this worker may load; the adapter maps it onto its harness's flags. */
  readonly workers?: WorkerPolicy;
}

/** Native process/session information an adapter may use to classify state. */
export interface StateDetectionInput {
  /** Latest adapter-native output, if state is reported in a stream or log. */
  readonly output?: string;
  /** Exit status when the process has terminated. */
  readonly exitCode?: number;
  /** Termination signal, when the process was signalled. */
  readonly signal?: string;
}

/** Request passed to an adapter's steering mechanism. */
export interface SteerRequest {
  /** Target presence key or adapter-native session identifier. */
  readonly key: string;
  /** Text to deliver to the running agent. */
  readonly text: string;
  /** Outbox id used to acknowledge lossless inbox delivery. */
  readonly id?: string;
  /** Session options needed by resume- or keys-based delivery. */
  readonly opts?: SpawnOpts;
}

/** Request passed to an adapter when switching a live session's model. */
export interface ModelRequest {
  /** Target presence key or adapter-native session identifier. */
  readonly key: string;
  /** Model specification to switch the running session to. */
  readonly model: string;
  /** Dispatcher request id the agent must echo into its control outcome. */
  readonly id: string;
}

/** Request passed to an adapter when answering a blocking question. */
export interface AnswerRequest {
  /** Target presence key or adapter-native session identifier. */
  readonly key: string;
  /** Answer text to deliver to the agent. */
  readonly text: string;
  /** Session options needed by the adapter's answer mechanism. */
  readonly opts?: SpawnOpts;
}

/** A command a backend can execute on an adapter's behalf. */
export interface AdapterCommand {
  /** Executable and arguments, without shell quoting. */
  readonly argv: readonly string[];
  /** Optional text to write to the command's standard input. */
  readonly stdin?: string;
}

/** Options for adapter shim installation during setup. */
export interface ShimInstallOpts {
  /** Copy shim artifacts instead of symlinking them. */
  readonly copy?: boolean;
}

/** Native output supplied to an adapter for final-result extraction. */
export interface ResultExtractionInput {
  /** Complete adapter-native output, when available. */
  readonly output?: string;
  /** Path to a native session transcript, when the adapter exposes one. */
  readonly sessionPath?: string;
}

/** A tool invocation summarized for a session-view assistant turn. */
export interface SessionViewToolCall {
  /** Tool name, or "tool" when the adapter cannot name it. */
  readonly name: string;
  /** The most descriptive argument value the adapter recovered, unformatted (commands own truncation/collapsing). */
  readonly arg: string;
}

/**
 * One content-bearing turn in a session view, normalized across harnesses so
 * `orch tail`/`orch session` can render per-turn rows without importing any
 * per-harness session parser. Adapters emit only renderable turns; commands own
 * all layout (columns, role labels, timestamps, truncation, collapsing).
 */
export interface SessionViewEntry {
  /** Turn role, normalized to orch's three tail rows. */
  readonly role: "user" | "assistant" | "tool";
  /** Flattened turn text, when the turn carries any. */
  readonly text?: string;
  /** Tool calls for an assistant turn that only invoked tools; omitted otherwise. */
  readonly toolCalls?: readonly SessionViewToolCall[];
  /** Tool name for a tool-result turn. */
  readonly tool?: string;
  /** Whether a tool-result turn reported an error. */
  readonly isError?: boolean;
  /** ISO timestamp of the turn, when the session records one. */
  readonly timestamp?: string;
}

/** Supplementary display data an adapter can recover from its native session output. */
export interface SessionView {
  /** Presence-protocol state inferred from session content, when the adapter derives one. */
  readonly state?: AgentState;
  /** Active model identifier, when the session records one. */
  readonly model?: string;
  /** Model provider, when the session records one. */
  readonly provider?: string;
  /** Active thinking/reasoning level, when the session records one. */
  readonly thinking?: string;
  /** Most recent user task/prompt text, when the session records one. */
  readonly task?: string;
  /** Most recent assistant text, when the session records one. */
  readonly lastText?: string;
  /** Accumulated cost, when the session records one. */
  readonly cost?: number;
  /** Token usage totals, when the session records them. */
  readonly tokens?: unknown;
  /** Completed turn count, when the session records one. */
  readonly turns?: number;
  /**
   * Per-turn items for rich tailing, populated by adapters whose parser can
   * produce them. Commands render the header+last-text fallback when omitted;
   * an empty array means the session was read but had no content-bearing turns.
   */
  readonly entries?: readonly SessionViewEntry[];
}

/** Input to an adapter's session-tail read. */
export interface SessionViewInput {
  /** Path to the adapter-native session/transcript file, when one exists on disk. */
  readonly sessionPath?: string;
  /** Native process output captured in memory, when no on-disk session path applies. */
  readonly output?: string;
}

/**
 * Contract implemented by each agent CLI adapter.
 *
 * Adapters translate agent-native behavior into orch's presence protocol;
 * core commands must continue to consume presence data rather than native formats.
 */
export interface AgentAdapter {
  /** Stable adapter id recorded in the spawn registry and presence status. */
  readonly id: AdapterId;
  /**
   * Declared behavior limits used by commands to choose safe fallbacks or fail clearly.
   */
  readonly caps: {
    /** Steering mechanism: inbox is lossless, keys/resume are degraded, none is unsupported. */
    readonly steer: SteerMechanism;
    /** Whether the adapter can participate in orch's blocking question/answer flow. */
    readonly ask: boolean;
    /** Whether `orch model` can change this adapter's active model. */
    readonly setModel: boolean;
    /** Whether native session output can be tailed for supplementary state/result data. */
    readonly sessionTail: boolean;
    /** Session-lifecycle verbs (reset/reload/restart) this adapter declares a native mechanism for; empty when none. */
    readonly lifecycle: readonly LifecycleVerb[];
    /** Whether the adapter has a pre-tool seam that can transparently wrap locked commands in the machine-wide lock (pi bridge); false adapters get the worker-prompt clause only, and doctor/setup report the gap. */
    readonly enforcesCommandLocks: boolean;
  };
  /** Build the normal shell command used to start one agent in an interactive pane. */
  interactiveCmd(opts: SpawnOpts): string;
  /**
   * Build the restricted shell command used for worker launches.
   * Adapters that cannot enforce a tool allowlist return their normal command;
   * this is an explicit capability gap rather than an implicit global discovery.
   * Omit this method when the adapter cannot restrict launches.
   */
  restrictedInteractiveCmd?(opts: SpawnOpts): string;
  /** Build argv for a detached backend, including the initial prompt. */
  headlessCmd(prompt: string, opts: SpawnOpts): string[];
  /**
   * Build restricted argv for a detached worker, including the initial prompt.
   * Adapters without allowlist support may omit this method or return headlessCmd(prompt, opts).
   */
  restrictedHeadlessCmd?(prompt: string, opts: SpawnOpts): string[];
  /** Translate native process/session signals into a presence-protocol state. */
  detectState(input: StateDetectionInput): AgentState;
  /** Build the command or presence action used to deliver a steering message. */
  steer(request: SteerRequest): AdapterCommand | undefined;
  /** Build the command or presence action used to answer a blocking question. */
  answer(request: AnswerRequest): AdapterCommand | undefined;
  /** Build the command or presence action used to switch the active model; present only when caps.setModel is true. */
  setModel?(request: ModelRequest): AdapterCommand | undefined;
  /** Build the delivery text for a lifecycle verb; called only when caps.lifecycle includes that verb. */
  lifecycleCmd?(verb: LifecycleVerb): { text: string } | undefined;
  /** Extract the final assistant text that should be written to `result.json`. */
  extractResult(input: ResultExtractionInput): string | undefined;
  /**
   * Read supplementary state/model/cost/task/result data from the adapter's
   * native session output. Declared only by adapters with `caps.sessionTail`;
   * callers must gate on that capability, never on method presence.
   */
  readSessionView?(input: SessionViewInput): SessionView | undefined;
  /**
   * Seed the adapter's own trust/approval store for `cwd` before a launch.
   * `cmd` is the shell command the launcher will actually run, so an adapter
   * can skip seeding when a custom --cmd does not start its CLI.
   * Omit this method when the adapter has no trust store.
   */
  preTrustWorkspace?(cwd: string, cmd: string): void;
  /** Install adapter-specific hooks/shims without removing unrelated user setup. */
  installShim?(opts?: ShimInstallOpts): void | Promise<void>;
  /**
   * Verify exactly the integration artifacts written by installShim for this adapter.
   * Omit this method when the adapter declares no integration shim.
   */
  diagnoseShim?(): CheckResult | Promise<CheckResult>;
  /** The adapter's persisted default model, for display; undefined if it has none. */
  defaultModelString?(): string | undefined;
}
