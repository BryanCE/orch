import * as path from "node:path";
import { loadConfig } from "../config.ts";
import { buildEntities, collapse, resolveTarget, scopeEntitiesToWorkspace, workspaceOf, type Entity } from "../entities.ts";
import { loadPresence, orchDir, readJSON, type PresenceEntry } from "../presence/store.ts";
import { QUESTION_FILE } from "../presence/schema.ts";
import { isRecord, truncate } from "../util.ts";
import { renderTable } from "../table.ts";
import { runRemoteAsync, runSSH } from "../remote.ts";
import type { AgentAdapter, SessionView, SessionViewEntry } from "../adapters/adapter.ts";
import { die, remoteCommandArgs, resultText, splitOptionFlags, targetHost } from "./target.ts";
import { entityAdapter } from "./status.ts";

interface QuestionRow { key: string; name: string | null; age: string; question: string; workspace?: string; host?: string; warning?: string }

interface QuestionPayload { ts?: unknown; question: string }


export function cmdResult(args: string[]) {
  const json = args.includes("--json");
  const rest = args.filter((a) => !a.startsWith("--"));
  const target = rest[0];
  if (!target) die("usage: orch result <target> [--json]");
  const remote = targetHost(target);
  if (remote) {
    const host = loadConfig(orchDir()).hosts[remote.host];
    const destination = host?.dest;
    if (!host || !destination) die(`Host "${remote.host}" has no SSH destination.`);
    const result = runSSH(destination, remoteCommandArgs(host, "result", [remote.target, ...(json ? ["--json"] : [])]), { timeoutMs: host.timeout_ms });
    if (!result.ok) die(`Host "${remote.host}" is unreachable: ${result.stderr.trim() || "ssh failed"}`);
    process.stdout.write(result.stdout.endsWith("\n") ? result.stdout : result.stdout + "\n");
    return;
  }
  const ent = resolveTarget(target);
  const pres = ent.presence;
  if (pres?.result) {
    if (json) process.stdout.write(JSON.stringify(pres.result, null, 2) + "\n");
    else process.stdout.write((resultText(pres.result) ?? "") + "\n");
    return;
  }
  // fallback: adapter-extracted final text from the native session tail
  const adapter = entityAdapter(ent);
  const extractInput = { key: ent.key, sessionPath: ent.sessionPath ?? undefined };
  const text = adapter?.extractResult(extractInput);
  if (text) {
    process.stderr.write("(no result.json — falling back to adapter-extracted session text)\n");
    if (json) {
      const sview = adapter?.caps.sessionTail
        ? adapter.readSessionView?.({ sessionPath: ent.sessionPath ?? undefined })
        : undefined;
      process.stdout.write(
        JSON.stringify(
          {
            text,
            task: sview?.task ?? null,
            model: sview?.model ?? null,
            thinking: sview?.thinking ?? null,
            tokens: sview?.tokens ?? null,
            cost: sview?.cost ?? null,
            turns: sview?.turns ?? null,
            sessionPath: ent.sessionPath,
          },
          null,
          2
        ) + "\n"
      );
    } else process.stdout.write(text + "\n");
    return;
  }
  die(`No result available for "${target}" (no result.json and no adapter-extractable session text).`);
}

export async function cmdQuestions(args: string[]): Promise<void> {
  const { enabled } = splitOptionFlags(args, ["--all", "--json", "--local"]);
  const json = enabled.has("--json");
  const localOnly = enabled.has("--local");
  const hosts = loadConfig(orchDir()).hosts;
  if (localOnly || Object.keys(hosts).length === 0) {
    cmdQuestionsLocal(args);
    return;
  }
  const rows: QuestionRow[] = [...localQuestionRows(args)];
  const remoteResults = await Promise.all(Object.entries(hosts).map(async ([name, host]) => ({
    name,
    result: await runRemoteAsync(name, host, ["questions"], { timeoutMs: host.timeout_ms }),
  })));
  for (const { name, result } of remoteResults) {
    if (!result.ok) {
      rows.push(warningQuestionRow(name, result.failure.message));
      continue;
    }
    if (!Array.isArray(result.value)) {
      rows.push(warningQuestionRow(name, `Host "${name}" returned an invalid questions payload.`));
      continue;
    }
    for (const value of result.value) if (value && typeof value === "object") rows.push({ ...(value as QuestionRow), host: name });
  }
  if (json) {
    process.stdout.write(JSON.stringify(rows, null, 2) + "\n");
    return;
  }
  if (!rows.length) {
    process.stdout.write("No pending questions.\n");
    return;
  }
  const tableRows = rows.map((row) => [row.host ?? "local", row.key, row.name ?? "-", row.age, row.question]);
  process.stdout.write(renderTable(["HOST", "PANE", "NAME", "AGE", "QUESTION"], tableRows, [10, 24, 20, 8, 100]) + "\n");
}

interface PendingQuestion { pres: PresenceEntry; question: QuestionPayload }

/**
 * The pending local questions (a scoped presence dir holding a valid
 * `question.json`) sorted by presence key, with the display-name map for the
 * scoped entities. The one collector behind both the `orch questions` local
 * table and the merged-with-remote row builder.
 */
function collectPendingQuestions(args: string[]): { pending: PendingQuestion[]; names: Map<string, string> } {
  const { enabled } = splitOptionFlags(args, ["--all", "--json", "--local"]);
  const all = enabled.has("--all");
  const scopedEntities = scopeEntitiesToWorkspace(buildEntities(), { all });
  const names = new Map<string, string>();
  const scopedKeys = new Set<string>();
  for (const ent of scopedEntities) {
    scopedKeys.add(ent.key);
    if (ent.presence) scopedKeys.add(ent.presence.key);
    if (ent.name) {
      names.set(ent.key, ent.name);
      if (ent.paneId) names.set(ent.paneId, ent.name);
      if (ent.presence) names.set(ent.presence.key, ent.name);
    }
  }
  // A dead agent's question can never be answered — its presence dir outlives the
  // process, so an unfiltered listing accumulates questions from panes closed
  // hours ago and a scripted answer loop steers targets that no longer exist.
  const pending = [...loadPresence().values()]
    .filter((pres) => pres.alive && (scopedKeys.has(pres.key) || all))
    .map((pres) => ({ pres, question: readJSON<unknown>(path.join(pres.dir, QUESTION_FILE)) }))
    .filter((entry): entry is PendingQuestion => isQuestionPayload(entry.question))
    .sort((a, b) => a.pres.key.localeCompare(b.pres.key));
  return { pending, names };
}

function cmdQuestionsLocal(args: string[]) {
  const { enabled } = splitOptionFlags(args, ["--all", "--json", "--local"]);
  const all = enabled.has("--all");
  const { pending, names } = collectPendingQuestions(args);
  if (!pending.length) {
    if (enabled.has("--json")) process.stdout.write("[]\n");
    else process.stdout.write("No pending questions.\n");
    return;
  }
  if (enabled.has("--json")) {
    process.stdout.write(JSON.stringify(pending.map(({ pres, question }) => ({
      key: pres.key,
      name: names.get(pres.key) ?? null,
      age: formatAge(question.ts),
      question: questionText(question),
      workspace: workspaceOf(pres.key) ?? "-",
      host: "local",
    })), null, 2) + "\n");
    return;
  }
  const workspaces = pending.map(({ pres }) => workspaceOf(pres.key) ?? "-");
  const showWorkspace = all && new Set(workspaces).size > 1;
  process.stdout.write(
    pending
      .map(({ pres, question }) => {
        const label = names.get(pres.key) ?? "-";
        const workspaceLabel = workspaceOf(pres.key) ?? "-";
        const name = showWorkspace ? `${workspaceLabel} / ${label}` : label;
        return `${pres.key}  ${name}  ${formatAge(question.ts)}\n${question.question}`;
      })
      .join("\n\n") + "\n"
  );
}

export function formatAge(ts: unknown): string {
  const when = new Date(typeof ts === "string" ? ts : JSON.stringify(ts) ?? "").getTime();
  if (!Number.isFinite(when)) return "?";
  const seconds = Math.max(0, Math.floor((Date.now() - when) / 1000));
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  return `${Math.floor(seconds / 86400)}d`;
}

export function isQuestionPayload(value: unknown): value is QuestionPayload {
  return isRecord(value) && typeof value.question === "string";
}

export function questionText(value: unknown): string {
  return isRecord(value) && typeof value.question === "string" ? value.question : "";
}

function localQuestionRows(args: string[]): QuestionRow[] {
  const { pending, names } = collectPendingQuestions(args);
  return pending.map(({ pres, question }) => ({
    key: pres.key, name: names.get(pres.key) ?? null, age: formatAge(question.ts),
    question: questionText(question), workspace: workspaceOf(pres.key) ?? "-", host: "local",
  }));
}

function warningQuestionRow(host: string, warning: string): QuestionRow {
  return { key: `warning:${host}`, name: "WARNING", age: "-", question: warning, host, warning };
}

/** Resolve the target's adapter and require a declared session-tail capability, or die. */
function resolveSessionTailAdapter(target: string, ent: Entity): AgentAdapter {
  const adapter = entityAdapter(ent);
  if (!adapter?.caps.sessionTail) {
    die(`Target "${target}" (${adapter?.id ?? "unknown adapter"}) exposes no session tail; a session is read only through an adapter that declares one.`);
  }
  return adapter;
}

/** The model line for a session view: `provider/model:thinking`, or `fallback` when unknown. */
function formatViewModel(view: SessionView, fallback: string): string {
  if (!view.model) return fallback;
  return `${view.provider ? view.provider + "/" : ""}${view.model}${view.thinking ? ":" + view.thinking : ""}`;
}

/** Token totals line from a session view's opaque token record. */
function formatViewTokens(tokens: unknown): string {
  const count = (value: unknown): number => (typeof value === "number" ? value : 0);
  if (!isRecord(tokens)) return "in 0 / out 0 / cacheR 0 / cacheW 0";
  return `in ${count(tokens.input)} / out ${count(tokens.output)} / cacheR ${count(tokens.cacheRead)} / cacheW ${count(tokens.cacheWrite)}`;
}

/** The last assistant text of a session view, tailed to its final `lines` lines. */
function tailLastText(view: SessionView, lines: number): string {
  const text = view.lastText;
  if (!text) return "(no session text)";
  return text.split(/\r?\n/).slice(-lines).join("\n");
}

/** The HH:MM:SS prefix for a turn timestamp, or blank padding when absent or invalid. */
function hms(timestamp: string | undefined): string {
  const when = timestamp ? new Date(timestamp) : null;
  if (!when || isNaN(when.getTime())) return "        ";
  return when.toTimeString().slice(0, 8);
}

/** Lay out one normalized session-view turn as a tail row, or undefined to skip a pure-thinking turn. */
function renderViewEntry(entry: SessionViewEntry): string | undefined {
  const time = hms(entry.timestamp);
  if (entry.role === "user") {
    const text = collapse(entry.text ?? "");
    return text ? `${time} user      │ ${truncate(text, 200)}` : undefined;
  }
  if (entry.role === "assistant") {
    const text = collapse(entry.text ?? "");
    if (text) return `${time} assistant │ ${truncate(text, 200)}`;
    if (entry.toolCalls?.length) {
      const calls = entry.toolCalls.map((call) => `${call.name}(${collapse(truncate(call.arg, 60))})`).join(", ");
      return `${time} assistant │ ⚙ ${calls}`;
    }
    return undefined;
  }
  const mark = entry.isError ? " [err]" : "";
  return `${time} tool      │ ${entry.tool ?? "tool"}${mark} → ${truncate(collapse(entry.text ?? ""), 120)}`;
}

/** The last-N rendered per-turn rows of a session view, or the "(no entries)" marker. */
function tailEntries(entries: readonly SessionViewEntry[], count: number): string {
  const rows = entries.map(renderViewEntry).filter((row): row is string => row !== undefined).slice(-count);
  return rows.length ? rows.join("\n") : "(no entries)";
}

export function cmdTail(args: string[]) {
  let n = 20;
  let json = false;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === undefined) continue;
    if (arg === "-n") {
      const value = args[++i];
      n = parseInt(value ?? "", 10) || 20;
    } else if (arg === "--json") json = true;
    else rest.push(arg);
  }
  const target = rest[0];
  if (!target) die("usage: orch tail <target> [-n N] [--json]");
  const ent = resolveTarget(target);
  const adapter = resolveSessionTailAdapter(target, ent);
  const view = adapter.readSessionView?.({ sessionPath: ent.sessionPath ?? undefined });
  if (!view) die(`No session data for "${target}" (${ent.sessionPath ?? "unknown path"}).`);
  if (json) {
    process.stdout.write(JSON.stringify({ target, sessionPath: ent.sessionPath, model: view.model ?? null,
      provider: view.provider ?? null, thinking: view.thinking ?? null, cost: view.cost ?? null,
      tokens: view.tokens ?? null, turns: view.turns ?? null, task: view.task ?? null, lastText: view.lastText ?? null,
      entries: view.entries ? view.entries.slice(-n) : null }, null, 2) + "\n");
    return;
  }
  process.stdout.write(
    `session: ${ent.sessionPath}\nmodel: ${formatViewModel(view, "-")}   cost: $${(view.cost ?? 0).toFixed(4)}   turns: ${view.turns ?? 0}\n\n`
  );
  // Adapters whose parser yields per-turn entries get the rich last-N tail; the
  // rest fall back to the last assistant text tailed to its final N lines.
  process.stdout.write((view.entries ? tailEntries(view.entries, n) : tailLastText(view, n)) + "\n");
}

export function cmdSession(args: string[]) {
  const json = args.includes("--json");
  const target = args.find((arg) => arg !== "--json");
  if (!target) die("usage: orch session <target> [--json]");
  const ent = resolveTarget(target);
  if (!ent.sessionPath) die(`No session path known for "${target}".`);
  const adapter = resolveSessionTailAdapter(target, ent);
  const view = adapter.readSessionView?.({ sessionPath: ent.sessionPath });
  const entryCount = view?.entries?.length ?? 0;
  if (json) {
    process.stdout.write(JSON.stringify({ path: ent.sessionPath, exists: view !== undefined,
      entries: entryCount, turns: view?.turns ?? 0, cost: view?.cost ?? 0, tokens: view?.tokens ?? null,
      model: view?.model ?? null, provider: view?.provider ?? null, thinking: view?.thinking ?? null }, null, 2) + "\n");
    return;
  }
  process.stdout.write(
    [
      `path:    ${ent.sessionPath}`,
      `exists:  ${view !== undefined}`,
      `entries: ${entryCount}`,
      `turns:   ${view?.turns ?? 0}`,
      `cost:    $${(view?.cost ?? 0).toFixed(4)}`,
      `tokens:  ${formatViewTokens(view?.tokens)}`,
      `model:   ${view ? formatViewModel(view, "(none)") : "(none)"}`,
    ].join("\n") + "\n"
  );
}

