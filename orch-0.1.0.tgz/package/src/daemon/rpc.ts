import { createConnection, createServer, type Server, type Socket } from "node:net";
import { existsSync, mkdirSync, unlinkSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { readDaemonLock } from "./lifecycle.ts";
import { readPortFile } from "../presence/socket-client.ts";
import { errorMessage } from "../util.ts";

export type RpcParams = unknown;
export type RpcEventEmitter = (event: unknown) => void;
export type RpcHandler = (params: RpcParams, emit: RpcEventEmitter) => unknown;
export type RpcHandlers = Record<string, RpcHandler>;

export class DaemonAbsentError extends Error {
  readonly code = "DAEMON_ABSENT";

  constructor(orchDir: string) {
    super(`orchd daemon is absent (${orchDir})`);
    this.name = "DaemonAbsentError";
  }
}

export class RpcError extends Error {
  readonly code: string | number;
  readonly data: unknown;

  constructor(code: string | number, message: string, data?: unknown) {
    super(message);
    this.name = "RpcError";
    this.code = code;
    this.data = data;
  }
}

export interface RpcServerOptions {
  /** Allow one stale unix endpoint to be removed during daemon boot. */
  holdsDaemonLock?: boolean;
  /** TCP port to bind on loopback alongside the unix socket. */
  tcpPort?: number;
  /** Report a TCP bind failure without taking down the unix listener. */
  onTcpError?: (error: unknown, port: number) => void;
};

export interface BufferedEvent {
  seq: number;
  event: unknown;
}

export interface ReplayResult {
  events: BufferedEvent[];
  gap: boolean;
  oldestSeq?: number;
}

export const REPLAY_WINDOW = 1_000;

export class ReplayBuffer {
  private readonly events: BufferedEvent[] = [];
  private nextSeq = 1;

  push(event: unknown): BufferedEvent {
    const buffered: BufferedEvent = { event, seq: this.nextSeq++ };
    this.events.push(buffered);
    if (this.events.length > REPLAY_WINDOW) this.events.shift();
    return buffered;
  }

  since(seq: number): ReplayResult {
    const oldestSeq = this.events[0]?.seq;
    return {
      events: this.events.filter((event) => event.seq > seq),
      gap: oldestSeq !== undefined && oldestSeq > seq + 1,
      ...(oldestSeq === undefined ? {} : { oldestSeq }),
    };
  }
}

export interface RpcServer {
  /** Stop accepting connections and remove the endpoint files. */
  close(): Promise<void>;
  /** Alias for close(), useful to callers that use server lifecycle wording. */
  stop(): Promise<void>;
  /** Push an event to every connection subscribed with subscribe-events. */
  emit(event: unknown): void;
  readonly transport: "unix" | "tcp";
  readonly socketPath: string;
  readonly portFile: string;
  readonly tcpEndpoint?: string;
}

interface RpcResponse {
  id?: unknown;
  event?: unknown;
  seq?: number;
  gap?: boolean;
  oldestSeq?: number;
  result?: unknown;
  error?: { code?: string | number; message?: string; data?: unknown } | string;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

const SOCKET_NAME = "orchd.sock";
const PORT_NAME = "orchd.port";
const DEFAULT_TIMEOUT_MS = 5_000;
// Bounds for the self-healing event subscription's reconnect loop. A daemon can
// return at any time (restart, reload, machine wake), so retries never give up;
// they only stop climbing once the delay reaches the cap.
const RECONNECT_BASE_MS = 250;
const RECONNECT_CAP_MS = 5_000;
let nextRequestId = 1;

function endpointPaths(orchDir: string): { socket: string; port: string } {
  return { socket: join(orchDir, SOCKET_NAME), port: join(orchDir, PORT_NAME) };
}

function lineResponse(socket: Socket, response: RpcResponse): void {
  if (!socket.destroyed) socket.write(`${JSON.stringify(response)}\n`);
}

function errorResponse(id: unknown, code: string, message: string): RpcResponse {
  return { id, error: { code, message } };
}

function parseRequest(line: string): { id: unknown; method: string; params: unknown } | RpcResponse {
  let request: unknown;
  try {
    request = JSON.parse(line);
  } catch {
    return errorResponse(null, "INVALID_REQUEST", "Malformed JSON request");
  }
  if (!request || typeof request !== "object" || Array.isArray(request)) {
    return errorResponse(null, "INVALID_REQUEST", "Request must be a JSON object");
  }
  const value = request as Record<string, unknown>;
  if (typeof value.method !== "string" || value.method.length === 0) {
    return errorResponse(value.id ?? null, "INVALID_REQUEST", "Request method must be a non-empty string");
  }
  return { id: value.id ?? null, method: value.method, params: value.params };
}

function handleLine(
  socket: Socket,
  line: string,
  handlers: RpcHandlers,
  subscriptions: Set<Socket>,
  replayBuffer: ReplayBuffer,
): void {
  const request = parseRequest(line);
  if (!("method" in request)) {
    lineResponse(socket, request);
    return;
  }
  if (request.method === "subscribe-events") {
    const params = isObject(request.params) ? request.params : undefined;
    const since = params?.since;
    if (typeof since === "number" && Number.isInteger(since)) {
      const replay = replayBuffer.since(since);
      if (replay.gap) lineResponse(socket, { gap: true, oldestSeq: replay.oldestSeq });
      for (const buffered of replay.events) lineResponse(socket, buffered);
    }
    subscriptions.add(socket);
  }
  const emit: RpcEventEmitter = (event) => lineResponse(socket, { event });
  const handler = handlers[request.method];
  if (!handler) {
    lineResponse(socket, errorResponse(request.id, "METHOD_NOT_FOUND", `Unknown method: ${request.method}`));
    return;
  }
  Promise.resolve()
    .then(() => handler(request.params, emit))
    .then((result) => lineResponse(socket, { id: request.id, result }))
    .catch((error: unknown) => {
      lineResponse(socket, errorResponse(request.id, "HANDLER_ERROR", errorMessage(error)));
    });
}

/**
 * Drive `onLine` for each newline-framed line arriving on `socket`, buffering
 * partial lines across chunks. This owns only the framing loop — encoding,
 * split-on-newline, and cross-chunk buffering. Callers keep their own error,
 * close, and per-line parse semantics by attaching those listeners themselves
 * and doing any trim/parse inside `onLine`.
 */
function framedLineReader(socket: Socket, onLine: (line: string) => void): void {
  let buffer = "";
  socket.setEncoding("utf8");
  socket.on("data", (chunk: string) => {
    buffer += chunk;
    let newline = buffer.indexOf("\n");
    while (newline >= 0) {
      const line = buffer.slice(0, newline);
      buffer = buffer.slice(newline + 1);
      onLine(line);
      newline = buffer.indexOf("\n");
    }
  });
}

function attachConnection(
  socket: Socket,
  handlers: RpcHandlers,
  subscriptions: Set<Socket>,
  replayBuffer: ReplayBuffer,
): void {
  framedLineReader(socket, (line) =>
    handleLine(socket, line.replace(/\r$/, ""), handlers, subscriptions, replayBuffer),
  );
  socket.on("close", () => subscriptions.delete(socket));
  socket.on("error", () => subscriptions.delete(socket));
}

function listen(server: Server, endpoint: string | { port: number; host: string }): Promise<void> {
  return new Promise((resolve, reject) => {
    const onError = (error: Error) => {
      server.off("listening", onListening);
      reject(error);
    };
    const onListening = () => {
      server.off("error", onError);
      resolve();
    };
    server.once("error", onError);
    server.once("listening", onListening);
    server.listen(endpoint);
  });
}

function connect(pathOrPort: string | number, timeoutMs: number): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = typeof pathOrPort === "string"
      ? createConnection(pathOrPort)
      : createConnection({ host: "127.0.0.1", port: pathOrPort });
    let settled = false;
    // The timeout rejects WITHOUT destroying: tearing down a socket whose
    // native connect is still in flight makes the late completion surface as
    // an uncatchable error on Windows. The connect/error handlers stay armed
    // and destroy the socket once the native attempt actually settles.
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      socket.unref();
      reject(new Error("RPC connection timed out"));
    }, timeoutMs);
    socket.once("connect", () => {
      clearTimeout(timer);
      if (settled) {
        socket.destroy();
        return;
      }
      settled = true;
      resolve(socket);
    });
    // "on", not "once": a Windows pipe connect can emit a second error after the
    // first settles the promise — an unlistened emission throws in the caller.
    socket.on("error", (error: Error) => {
      clearTimeout(timer);
      socket.destroy();
      if (settled) return;
      settled = true;
      reject(error);
    });
  });
}

/** Dial one daemon endpoint, or null when it is absent or unreachable. An absent
 *  unix-socket path is skipped without dialing — a dead pipe path can fault
 *  uncatchably on Windows, and a missing endpoint is "daemon absent" regardless. */
async function dialEndpoint(endpoint: string | number | undefined, timeoutMs: number): Promise<Socket | null> {
  if (endpoint === undefined) return null;
  if (typeof endpoint === "string" && !existsSync(endpoint)) return null;
  try {
    return await connect(endpoint, timeoutMs);
  } catch {
    return null;
  }
}

async function connectDaemon(orchDir: string, timeoutMs: number): Promise<Socket> {
  const paths = endpointPaths(orchDir);
  const connection = (await dialEndpoint(paths.socket, timeoutMs))
    ?? (await dialEndpoint(readPortFile(orchDir), timeoutMs));
  if (!connection) throw new DaemonAbsentError(orchDir);
  return connection;
}

function responseError(response: RpcResponse): RpcError {
  const error = response.error;
  if (typeof error === "string") return new RpcError("RPC_ERROR", error);
  return new RpcError(error?.code ?? "RPC_ERROR", error?.message ?? "RPC request failed", error?.data);
}

function receiveResponse(socket: Socket, id: number, timeoutMs: number): Promise<RpcResponse> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new Error("RPC request timed out"));
    }, timeoutMs);
    framedLineReader(socket, (raw) => {
      const line = raw.trim();
      if (!line) return;
      try {
        const parsed: unknown = JSON.parse(line);
        if (!isObject(parsed)) return;
        const message = parsed as unknown as RpcResponse;
        if (message.id === id) {
          clearTimeout(timer);
          resolve(message);
        }
      } catch {
        // Ignore unsolicited malformed data from a server.
      }
    });
    socket.once("error", (error) => {
      clearTimeout(timer);
      reject(error);
    });
    socket.once("close", () => {
      clearTimeout(timer);
      reject(new Error("RPC connection closed"));
    });
  });
}

/** Start the local RPC endpoint, preferring a unix socket and falling back to loopback TCP. */
export async function startRpcServer(
  orchDir: string,
  handlers: RpcHandlers,
  options: RpcServerOptions = {},
): Promise<RpcServer> {
  mkdirSync(orchDir, { recursive: true });
  const paths = endpointPaths(orchDir);
  const subscriptions = new Set<Socket>();
  const sockets = new Set<Socket>();
  const replayBuffer = new ReplayBuffer();
  const attach = (socket: Socket): void => {
    sockets.add(socket);
    attachConnection(socket, handlers, subscriptions, replayBuffer);
    socket.once("close", () => sockets.delete(socket));
  };
  const server = createServer(attach);
  let transport: "unix" | "tcp";
  let tcpServer: Server | undefined;
  let tcpEndpoint: string | undefined;
  try {
    await listen(server, paths.socket);
    transport = "unix";
    try {
      unlinkSync(paths.port);
    } catch {}
  } catch (unixError: unknown) {
    const lockHeld = options.holdsDaemonLock ?? readDaemonLock(orchDir)?.pid === process.pid;
    if (unixError instanceof Error && Reflect.get(unixError, "code") === "EADDRINUSE" && lockHeld) {
      try {
        unlinkSync(paths.socket);
        await listen(server, paths.socket);
        transport = "unix";
        try {
          unlinkSync(paths.port);
        } catch {}
        tcpServer = await startTcpServer(handlers, subscriptions, replayBuffer, sockets, options, paths);
        tcpEndpoint = tcpServer ? `tcp://127.0.0.1:${options.tcpPort}` : undefined;
        return makeRpcServer(server, tcpServer, sockets, subscriptions, replayBuffer, paths, transport, tcpEndpoint);
      } catch {
        // A live endpoint or an unremovable path still requires TCP fallback.
      }
    }
    try { server.close(); } catch {}
    tcpServer = createServer(attach);
    await listen(tcpServer, { host: "127.0.0.1", port: options.tcpPort ?? 0 });
    const boundPort = (tcpServer.address() as { port: number }).port;
    writeFileSync(paths.port, `${boundPort}\n`, { mode: 0o600 });
    transport = "tcp";
    tcpEndpoint = `tcp://127.0.0.1:${boundPort}`;
    return makeRpcServer(tcpServer, undefined, sockets, subscriptions, replayBuffer, paths, transport, tcpEndpoint);
  }
  tcpServer = await startTcpServer(handlers, subscriptions, replayBuffer, sockets, options, paths);
  tcpEndpoint = tcpServer ? `tcp://127.0.0.1:${options.tcpPort}` : undefined;
  return makeRpcServer(server, tcpServer, sockets, subscriptions, replayBuffer, paths, transport, tcpEndpoint);
}

async function startTcpServer(
  handlers: RpcHandlers,
  subscriptions: Set<Socket>,
  replayBuffer: ReplayBuffer,
  sockets: Set<Socket>,
  options: RpcServerOptions,
  paths: { socket: string; port: string },
): Promise<Server | undefined> {
  const port = options.tcpPort;
  if (port === undefined) return undefined;
  const tcpServer = createServer((socket) => {
    sockets.add(socket);
    attachConnection(socket, handlers, subscriptions, replayBuffer);
    socket.once("close", () => sockets.delete(socket));
  });
  try {
    await listen(tcpServer, { host: "127.0.0.1", port });
    writeFileSync(paths.port, `${port}\n`, { mode: 0o600 });
    return tcpServer;
  } catch (error: unknown) {
    try { tcpServer.close(); } catch {}
    options.onTcpError?.(error, port);
    return undefined;
  }
}

function makeRpcServer(
  server: Server,
  tcpServer: Server | undefined,
  sockets: Set<Socket>,
  subscriptions: Set<Socket>,
  replayBuffer: ReplayBuffer,
  paths: { socket: string; port: string },
  transport: "unix" | "tcp",
  tcpEndpoint?: string,
): RpcServer {
  const close = async (): Promise<void> => {
    for (const socket of sockets) socket.destroy();
    await Promise.all([server, tcpServer].filter((value): value is Server => value !== undefined).map((listener) => new Promise<void>((resolve) => {
      if (!listener.listening) return resolve();
      listener.close(() => resolve());
    })));
    try { unlinkSync(paths.socket); } catch {}
    try { unlinkSync(paths.port); } catch {}
    subscriptions.clear();
  };
  return {
    close,
    stop: close,
    emit: (event) => {
      const buffered = replayBuffer.push(event);
      for (const socket of subscriptions) lineResponse(socket, buffered);
    },
    transport,
    socketPath: paths.socket,
    portFile: paths.port,
    tcpEndpoint,
  };
}

/** Make one request, probing the unix socket before the loopback-TCP port file. */
export async function rpcCall(
  orchDir: string,
  method: string,
  params?: unknown,
  timeoutMs = DEFAULT_TIMEOUT_MS,
): Promise<unknown> {
  const socket = await connectDaemon(orchDir, timeoutMs);
  const id = nextRequestId++;
  try {
    socket.write(`${JSON.stringify({ id, method, params })}\n`);
    const response = await receiveResponse(socket, id, timeoutMs);
    if (response.error !== undefined) throw responseError(response);
    return response.result;
  } finally {
    socket.destroy();
  }
}

export interface EventSubscription {
  close(): void;
  readonly lastSeq: () => number;
}

/**
 * Subscribe to daemon-pushed events, self-healing across daemon restarts. The
 * socket dying is the disconnect signal: on close or error the subscription
 * redials with bounded exponential backoff — reading `orchd.port` fresh each
 * attempt via {@link connectDaemon}, since the port changes when the daemon
 * comes back on a new instance — and resubscribes on success. It retries
 * forever at the capped interval; only {@link EventSubscription.close} stops the
 * loop, and every timer is `unref`'d so a pending retry never keeps the process
 * alive.
 */
export function subscribeEvents(
  orchDir: string,
  opts: { since?: number },
  onEvent: (event: unknown, seq: number) => void,
  onGap?: (oldestSeq: number) => void,
): EventSubscription {
  let last = opts.since ?? 0;
  let socket: Socket | undefined;
  let closed = false;
  let connectedBefore = false;
  let retryTimer: ReturnType<typeof setTimeout> | undefined;
  let backoffMs = RECONNECT_BASE_MS;

  const scheduleReconnect = (): void => {
    if (closed || retryTimer) return;
    const delay = backoffMs;
    backoffMs = Math.min(backoffMs * 2, RECONNECT_CAP_MS);
    retryTimer = setTimeout(() => {
      retryTimer = undefined;
      connect();
    }, delay);
    retryTimer.unref?.();
  };

  // A dead socket means the daemon is gone; both error and close route here, but
  // only the first schedules — scheduleReconnect no-ops while a retry is pending.
  const onDisconnect = (): void => {
    socket = undefined;
    scheduleReconnect();
  };

  const connect = (): void => {
    if (closed) return;
    void connectDaemon(orchDir, DEFAULT_TIMEOUT_MS)
      .then((connected) => {
        if (closed) {
          connected.destroy();
          return;
        }
        socket = connected;
        backoffMs = RECONNECT_BASE_MS; // a healthy dial resets the climb
        framedLineReader(connected, (raw) => {
          const line = raw.trim();
          if (!line) return;
          try {
            const parsed: unknown = JSON.parse(line);
            if (!isObject(parsed)) return;
            const message = parsed as RpcResponse;
            if (message.gap === true && typeof message.oldestSeq === "number") {
              onGap?.(message.oldestSeq);
            } else if (message.seq !== undefined && typeof message.seq === "number" && "event" in message) {
              last = Math.max(last, message.seq);
              onEvent(message.event, message.seq);
            }
          } catch {
            // Ignore malformed unsolicited data from the daemon.
          }
        });
        connected.once("error", onDisconnect);
        connected.once("close", onDisconnect);
        // First dial honours the caller's `since` (undefined = live only). A
        // reconnect lands on a fresh daemon whose sequence numbers restarted
        // from 1, so `last` from the previous instance no longer maps to its
        // buffer — request `since: 0` to replay whatever the new daemon still
        // holds rather than silently miss its early events.
        const since = connectedBefore ? 0 : opts.since;
        connectedBefore = true;
        connected.write(`${JSON.stringify({
          id: nextRequestId++,
          method: "subscribe-events",
          params: { since },
        })}\n`);
      })
      .catch(() => {
        // Daemon absent or the dial failed; keep retrying — it may return.
        scheduleReconnect();
      });
  };

  connect();

  return {
    close: () => {
      closed = true;
      if (retryTimer) {
        clearTimeout(retryTimer);
        retryTimer = undefined;
      }
      socket?.destroy();
      socket = undefined;
    },
    lastSeq: () => last,
  };
}

/** Subscribe to pushed events; the returned function closes the subscription.
 *  `onClose` fires when the daemon drops the connection but NOT when the caller
 *  stops it — the socket is the disconnect signal, so no caller has to poll. */
export async function rpcSubscribe(
  orchDir: string,
  method: string,
  onEvent: (event: unknown) => void,
  onClose?: () => void,
): Promise<() => void> {
  const socket = await connectDaemon(orchDir, DEFAULT_TIMEOUT_MS);
  const id = nextRequestId++;
  let responseResolve!: (value: unknown) => void;
  let responseReject!: (reason?: unknown) => void;
  const response = new Promise<unknown>((resolve, reject) => {
    responseResolve = resolve;
    responseReject = reject;
  });
  framedLineReader(socket, (raw) => {
    const line = raw.trim();
    if (!line) return;
    try {
      const parsed: unknown = JSON.parse(line);
      if (!isObject(parsed)) return;
      const message = parsed as unknown as RpcResponse;
      if (Object.prototype.hasOwnProperty.call(message, "event")) {
        try {
          onEvent(message.event);
        } catch {}
      } else if (message.id === id) {
        if (message.error !== undefined) responseReject(responseError(message));
        else responseResolve(message.result);
      }
    } catch {}
  });
  socket.once("error", responseReject);
  socket.write(`${JSON.stringify({ id, method })}\n`);
  await response;
  let stopped = false;
  socket.on("close", () => { if (!stopped) onClose?.(); });
  return () => {
    stopped = true;
    socket.destroy();
  };
}
