import { spawn, execFile } from "node:child_process";
import * as filesystem from "node:fs";
import * as path from "node:path";
import { loadConfig } from "./config.ts";
import { allSinkProviders, getSinkProvider, hasSinkProvider, onSinkProviderRegistered, type SinkProvider } from "./notify-sinks.ts";
import { workspaceOf } from "./policy/workspace.ts";
import { errorMessage, packageRoot } from "./util.ts";

export interface NotifyEvent {
  host?: string;
  key: string;
  /** Origin workspace; derived from key when omitted. */
  workspace?: string;
  /** Human-assigned agent name. */
  agent: string | null;
  tab: string | null;
  /** Model id plus thinking level, e.g. terra:medium. */
  model: string | null;
  oldState: string;
  newState: string;
  task?: string;
  cost?: number;
  ts: string;
  lastError?: string;
};

/** A required configuration value collected for a notifier. */
export interface NotifierConfigField {
  /** Config key used by the notifier. */
  name: string;
  /** Human-readable prompt/label for the key. */
  label: string;
  description?: string;
  /** Whether setup and doctor should redact this value. */
  secret?: boolean;
};

/** Host-integration metadata kept separate from delivery behavior. */
export interface NotifierMetadata {
  /** Rich fields are used by setup; bare names remain contract-compatible. */
  requiredConfig: readonly (NotifierConfigField | string)[];
  description?: string;
};

/** Canonical host-integration contract. */
export interface Notifier {
  id: string;
  label: string;
  metadata: NotifierMetadata;
  /** A rejected availability probe is treated as unavailable by the registry. */
  available(config?: Record<string, unknown>): boolean | Promise<boolean>;
  /** Config is optional so phase-1 custom notifiers remain source-compatible. */
  deliver(event: NotifyEvent, config?: Record<string, unknown>): Promise<boolean>;
};

function providerNotifier(provider: SinkProvider): Notifier {
  return {
    id: provider.id,
    label: provider.label ?? provider.id,
    metadata: { description: provider.description, requiredConfig: [] },
    available: () => provider.available(),
    deliver: async (event) => {
      const { title, body } = notificationText(event);
      return !!(await provider.send(title, body));
    },
  };
}

/** A configured notifier entry from the settings.json `notify` array. */
export interface NotifierEntry {
  id: string;
  on: string[];
  config: Record<string, unknown>;
};

export interface DesktopSink { type: "desktop"; on: string[] }
export interface WebhookSink { type: "webhook"; on: string[]; url: string }
export interface CommandSink { type: "command"; on: string[]; command: string[] }
export interface RegisteredSink { type: string; on: string[]; [key: string]: unknown }
export type Sink = DesktopSink | WebhookSink | CommandSink | RegisteredSink;

function warning(message: string): void {
  process.stderr.write(`notify: ${message}\n`);
}


function stringArray(value: unknown): string[] | null {
  if (!Array.isArray(value) || !value.every((entry) => typeof entry === "string")) return null;
  return value;
}

/** Read configured notifier entries, accepting both `id` and legacy `type`. */
function loadNotifierEntries(orchDir: string): NotifierEntry[] {
  let entries: unknown[];
  try {
    entries = loadConfig(orchDir).notify;
  } catch (error) {
    warning(`could not load settings.json: ${oneLine(error)}`);
    return [];
  }

  const configured: NotifierEntry[] = [];
  for (const entry of entries) {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
      warning("invalid notify entry: expected an object");
      continue;
    }
    const value = entry as Record<string, unknown>;
    const id = value.id;
    const provider = typeof id === "string" ? getSinkProvider(id) : undefined;
    const on = value.on === undefined ? [...(provider?.onDefaults ?? ["blocked", "error"])] : stringArray(value.on);
    if (!on) {
      warning("invalid notify entry: on must be an array of strings");
      continue;
    }
    if (typeof id !== "string") {
      warning(`invalid notify entry: unknown sink type ${JSON.stringify(id)}`);
      continue;
    }
    const config: Record<string, unknown> = {};
    for (const [key, item] of Object.entries(value)) {
      if (key !== "id" && key !== "on") config[key] = item;
    }
    if (id === "webhook" && (typeof config.url !== "string" || !config.url)) {
      warning("invalid notify entry: webhook sink requires url");
      continue;
    }
    if (id === "command") {
      const commandValue = typeof config.command === "string" ? ["sh", "-c", config.command] : config.command;
      const command = stringArray(commandValue);
      if (!command?.length || !command[0]) {
        warning("invalid notify entry: command sink requires command");
        continue;
      }
      config.command = command;
    }
    if (!isRegisteredSink(id)) {
      warning(`invalid notify entry: unknown sink type ${JSON.stringify(id)}`);
      continue;
    }
    configured.push({ id, on, config });
  }
  return configured;
}

/** Load valid sink declarations from the settings.json `notify` array. */
export function loadSinks(orchDir: string): Sink[] {
  return loadNotifierEntries(orchDir).map((entry): Sink => {
    if (entry.id === "desktop") return { type: entry.id, on: entry.on };
    if (entry.id === "webhook") return { type: "webhook", on: entry.on, url: entry.config.url as string };
    if (entry.id === "command") return { type: "command", on: entry.on, command: entry.config.command as string[] };
    return { type: entry.id, on: entry.on };
  });
}

function oneLine(error: unknown): string {
  return errorMessage(error).replace(/\s+/g, " ").trim();
}

const WORKSPACE_COLORS = ["#2563eb", "#16a34a", "#d97706", "#dc2626", "#9333ea", "#0891b2", "#db2777", "#4f46e5"] as const;
const WORKSPACE_ANSI = [34, 32, 33, 31, 35, 36, 35, 34] as const;

/** Stable palette color for a workspace. */
export function workspaceColor(workspace: string): string {
  let hash = 2166136261;
  for (let index = 0; index < workspace.length; index++) {
    hash ^= workspace.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return WORKSPACE_COLORS[(hash >>> 0) % WORKSPACE_COLORS.length]!;
}

function workspaceAnsi(workspace: string): string {
  let hash = 2166136261;
  for (let index = 0; index < workspace.length; index++) {
    hash ^= workspace.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return `\u001b[${WORKSPACE_ANSI[(hash >>> 0) % WORKSPACE_ANSI.length]!}m`;
}

export function workspaceLabelForKey(key: string): string {
  const keyWorkspace = key.includes(":") ? key.split(":", 1)[0] : undefined;
  // A bare pane id is not a useful human-facing workspace label. Other
  // unscoped keys (for example task-1) are already caller-provided labels.
  const barePane = /^p[0-9A-Za-z]+$/.test(key);
  return workspaceOf(key) ?? keyWorkspace ?? (barePane ? "workspace" : key || "workspace");
}

function eventWorkspace(event: NotifyEvent): string {
  return event.workspace ?? workspaceLabelForKey(event.key);
}

/** Harness-neutral label used when presence has no human-assigned name. */
export function abstractAgentLabel(workspace: string, key: string): string {
  const shortId = key.includes(":") ? key.slice(key.lastIndexOf(":") + 1) : key;
  return `${workspace}/agent-${shortId}`;
}

function eventAgent(event: NotifyEvent, workspace: string): string {
  const agent = event.agent?.trim();
  const fallback = abstractAgentLabel(workspace, event.key);
  return [agent, fallback].find((value) => value !== undefined && value.length > 0) ?? fallback;
}

/** Structured form of the canonical notification text and event metadata. */
interface NotificationPayload {
  title: string;
  body: string;
  workspace: string;
  workspaceColor: string;
  host: string | null;
  key: string;
  agent: string | null;
  tab: string | null;
  model: string | null;
  oldState: string;
  newState: string;
  task: string | null;
  cost: number | null;
  ts: string;
  lastError: string | null;
};

/** Build the canonical structured payload consumed by non-text sinks. */
function notificationPayload(event: NotifyEvent): NotificationPayload {
  const workspace = eventWorkspace(event);
  const { title, body } = notificationText(event);
  return {
    title,
    body,
    workspace,
    workspaceColor: workspaceColor(workspace),
    host: event.host ?? null,
    key: event.key,
    agent: eventAgent(event, workspace),
    tab: event.tab,
    model: event.model,
    oldState: event.oldState,
    newState: event.newState,
    task: event.task ?? null,
    cost: event.cost ?? null,
    ts: event.ts,
    lastError: event.lastError ?? null,
  };
}

function payload(event: NotifyEvent): string {
  return JSON.stringify(notificationPayload(event));
}

function isRegisteredSink(id: string): boolean {
  return id === "desktop" || id === "webhook" || id === "command" || hasSinkProvider(id);
}

function commandOnPath(command: string): boolean {
  for (const dir of (process.env.PATH ?? "").split(path.delimiter)) {
    if (dir && filesystem.existsSync(path.join(dir, command))) return true;
  }
  return false;
}

function run(command: string[], stdin?: string): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const proc = spawn(command[0]!, command.slice(1), {
        stdio: [stdin === undefined ? "ignore" : "pipe", "ignore", "ignore"],
      });
      proc.on("error", () => resolve(false));
      proc.on("close", (code) => resolve(code === 0));
      if (stdin !== undefined && proc.stdin) {
        proc.stdin.write(stdin);
        proc.stdin.end();
      }
    } catch {
      resolve(false);
    }
  });
}

export function notificationText(event: NotifyEvent, options: { colorize?: boolean } = {}): { title: string; body: string } {
  const workspace = eventWorkspace(event);
  const agent = eventAgent(event, workspace);
  const color = workspaceColor(workspace);
  const state = oneLine(event.newState || "unknown").toUpperCase();
  let summary = event.task ?? "state changed";
  if (event.newState === "error") summary = event.lastError ?? event.task ?? "agent error";
  else if (event.newState === "blocked") summary = event.task ?? "agent needs input";
  summary = oneLine(summary).replace(/^Q:\s*/i, "").slice(0, 60);
  const workspaceLabel = `[${workspace}]`;
  const coloredWorkspace = options.colorize ? `${workspaceAnsi(workspace)}${workspaceLabel}\u001b[0m` : workspaceLabel;
  const title = `${state} ${coloredWorkspace} ${agent}: ${summary}`;
  const details: string[] = [title, `Workspace: ${workspace} (${color})`];
  if (event.tab) details.push(`Tab: ${event.tab}`);
  if (event.model) details.push(`Model: ${event.model}`);
  if (event.task && event.newState !== "blocked") details.push(`Task: ${oneLine(event.task)}`);
  if (event.lastError && event.newState !== "error") details.push(`Error: ${oneLine(event.lastError)}`);
  if (typeof event.cost === "number") details.push(`Cost: $${event.cost.toFixed(2)}`);
  return { title, body: details.join("\n") };
}

async function windowsToast(title: string, body: string): Promise<boolean> {
  if (!commandOnPath("powershell.exe")) return false;
  const script = path.join(packageRoot(), "scripts", "wsl-toast.ps1");
  if (!filesystem.existsSync(script)) return false;
  try {
    const windowsPath = await new Promise<string>((resolve) => {
      execFile("wslpath", ["-w", script], { encoding: "utf8" }, (error, stdout) => {
        resolve(error ? "" : stdout.trim());
      });
    });
    if (!windowsPath) return false;
    return await run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", windowsPath, "-Title", title, "-Body", body]);
  } catch {
    return false;
  }
}

async function deliverDesktop(event: NotifyEvent): Promise<boolean> {
  const { title, body } = notificationText(event);
  if (await run(["notify-send", title, body])) return true;
  if (commandOnPath("wsl-notify-send") && await run(["wsl-notify-send", title, body])) return true;
  return windowsToast(title, body);
}

function desktopAvailable(): boolean {
  if (commandOnPath("notify-send") || commandOnPath("wsl-notify-send")) return true;
  return commandOnPath("powershell.exe") && commandOnPath("wslpath") && filesystem.existsSync(path.join(packageRoot(), "scripts", "wsl-toast.ps1"));
}

function commandAvailable(config: Record<string, unknown>): boolean {
  const command = stringArray(config.command);
  return !!command?.[0] && (command[0].includes(path.sep) ? filesystem.existsSync(command[0]) : commandOnPath(command[0]));
}

/** Built-in host integrations. Delivery always uses the canonical formatter above. */
export function createBuiltinNotifiers(): Notifier[] {
  return [
    ...allSinkProviders().map(providerNotifier),
    {
      id: "desktop",
      label: "Desktop",
      metadata: { description: "Desktop notifications with WSL fallback", requiredConfig: [] },
      available: () => desktopAvailable(),
      deliver: (event) => deliverDesktop(event),
    },
    {
      id: "webhook",
      label: "Webhook",
      metadata: { description: "HTTP POST notification", requiredConfig: [{ name: "url", label: "Webhook URL" }] },
      available: (config) => typeof fetch === "function" && (config?.url === undefined || (typeof config?.url === "string" && config.url.length > 0)),
      deliver: async (event, config = {}) => {
        if (typeof config.url !== "string" || !config.url) return false;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3000);
        try {
          const response = await fetch(config.url, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: payload(event),
            signal: controller.signal,
          });
          return response.ok;
        } finally {
          clearTimeout(timeout);
        }
      },
    },
    {
      id: "command",
      label: "Command",
      metadata: { description: "Run a command with canonical JSON on stdin", requiredConfig: [{ name: "command", label: "Command" }] },
      available: (config) => config?.command === undefined ? commandOnPath("sh") : commandAvailable(config),
      deliver: (event, config = {}) => {
        const command = stringArray(config.command);
        return command?.length ? run(command, payload(event)) : Promise.resolve(false);
      },
    },
  ];
}

const builtinNotifiers = createBuiltinNotifiers();

function entryFromSink(sink: Sink): NotifierEntry {
  // RegisteredSink's string discriminant defeats union narrowing; gate on the property instead.
  if (sink.type === "webhook" && "url" in sink) return { id: sink.type, on: sink.on, config: { url: sink.url } };
  if (sink.type === "command" && "command" in sink) return { id: sink.type, on: sink.on, config: { command: sink.command } };
  return { id: sink.type, on: sink.on, config: {} };
}

function timeoutResult<T>(promise: Promise<T>, timeoutMs: number): Promise<T | undefined> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(undefined), timeoutMs);
    promise.then((value) => { clearTimeout(timer); resolve(value); }, () => { clearTimeout(timer); resolve(undefined); });
  });
}

interface AvailabilityResult { available: boolean; reason?: string; error?: string }

/** Registry for probing, validating, and isolating configured notifier deliveries. */
class NotifierRegistry {
  private readonly notifiers = new Map<string, Notifier>();
  private readonly emitWarning: (message: string) => void;
  readonly timeoutMs: number;

  constructor(notifiers: readonly Notifier[] = builtinNotifiers, options: { timeoutMs?: number; warn?: (message: string) => void } = {}) {
    this.timeoutMs = options.timeoutMs ?? 3000;
    this.emitWarning = options.warn ?? ((message) => warning(message));
    for (const notifier of notifiers) this.register(notifier);
  }

  register(notifier: Notifier): this {
    this.notifiers.set(notifier.id, notifier);
    return this;
  }

  get(id: string): Notifier | undefined { return this.notifiers.get(id); }
  list(): Notifier[] { return [...this.notifiers.values()]; }

  validate(id: string, config: Record<string, unknown>): string[] {
    const notifier = this.notifiers.get(id);
    if (!notifier) return [`unknown notifier: ${id}`];
    return notifier.metadata.requiredConfig.flatMap((field) => {
      const name = typeof field === "string" ? field : field.name;
      const value = config[name];
      if (name === "command" ? !stringArray(value)?.length : typeof value !== "string" || !value.trim()) {
        return [`${id} requires ${name}`];
      }
      return [];
    });
  }

  /** Probe all integrations, or one integration with its configured metadata. */
  async probe(): Promise<Record<string, boolean>>;
  async probe(id: string, config?: Record<string, unknown>): Promise<AvailabilityResult>;
  async probe(id?: string, config: Record<string, unknown> = {}): Promise<Record<string, boolean> | AvailabilityResult> {
    if (id !== undefined) {
      const notifier = this.notifiers.get(id);
      if (!notifier) return { available: false, reason: "unknown notifier" };
      const errors = this.validate(id, config);
      if (errors.length) return { available: false, reason: errors.join("; ") };
      try {
        if (id === "command" && !commandAvailable(config)) return { available: false, reason: "configured command is not on PATH" };
        return (await notifier.available(config)) ? { available: true } : { available: false, reason: "host integration unavailable" };
      } catch (error) {
        return { available: false, error: oneLine(error) };
      }
    }
    const result: Record<string, boolean> = {};
    await Promise.all(this.list().map(async (notifier) => {
      try { result[notifier.id] = await notifier.available(); } catch { result[notifier.id] = false; }
    }));
    return result;
  }

  /** Alias used by setup/doctor callers. */
  probeAvailability(): Promise<Record<string, boolean>>;
  probeAvailability(id: string, config?: Record<string, unknown>): Promise<AvailabilityResult>;
  probeAvailability(id?: string, config: Record<string, unknown> = {}): Promise<Record<string, boolean> | AvailabilityResult> {
    return id === undefined ? this.probe() : this.probe(id, config);
  }

  async deliverEntry(entry: NotifierEntry, event: NotifyEvent, checkAvailability = true): Promise<boolean> {
    if (!entry.on.includes(event.newState)) return true;
    const notifier = this.notifiers.get(entry.id);
    if (!notifier) { this.emitWarning(`${entry.id} notifier is not registered`); return false; }
    if (this.validate(entry.id, entry.config).length) { this.emitWarning(`${entry.id} notifier has invalid configuration`); return false; }
    if (checkAvailability) {
      try {
        // A command's availability depends on its configured executable, not just the
        // shell used by the adapter. Keep this check in the registry so custom
        // Notifier implementations retain the phase-1 boolean probe contract.
        if (entry.id === "command" && !commandAvailable(entry.config)) {
          this.emitWarning(`${entry.id} notifier unavailable`);
          return false;
        }
        if (!(await notifier.available(entry.config))) { this.emitWarning(`${entry.id} notifier unavailable`); return false; }
      } catch { this.emitWarning(`${entry.id} notifier unavailable`); return false; }
    }
    const result = await timeoutResult(Promise.resolve().then(() => notifier.deliver(event, entry.config)), this.timeoutMs);
    if (result !== true) { this.emitWarning(`${entry.id} sink failed`); return false; }
    return true;
  }

  /** Deliver configured entries, or one id/config/event tuple for adapter callers. */
  async deliver(event: NotifyEvent, entries: readonly (NotifierEntry | Sink)[]): Promise<boolean[]>;
  async deliver(id: string, config: Record<string, unknown>, event: NotifyEvent): Promise<boolean>;
  async deliver(eventOrId: NotifyEvent | string, entriesOrConfig: readonly (NotifierEntry | Sink)[] | Record<string, unknown>, maybeEvent?: NotifyEvent): Promise<boolean[] | boolean> {
    if (typeof eventOrId === "string") {
      if (!maybeEvent) return false;
      return this.deliverEntry({ id: eventOrId, on: [maybeEvent.newState], config: entriesOrConfig as Record<string, unknown> }, maybeEvent, true);
    }
    const entries = entriesOrConfig as readonly (NotifierEntry | Sink)[];
    return Promise.all(entries.map((entry) => this.deliverEntry("type" in entry ? entryFromSink(entry) : entry, eventOrId, true)));
  }

  /** Queue best-effort delivery without delaying or throwing into producers. */
  notify(event: NotifyEvent, entries: readonly (NotifierEntry | Sink)[]): void {
    for (const entry of entries) {
      const configured = "type" in entry ? entryFromSink(entry) : entry;
      if (!configured.on.includes(event.newState)) continue;
      queueMicrotask(() => { void this.deliverEntry(configured, event, true); });
    }
  }
}

export function createNotifierRegistry(notifiers?: readonly Notifier[], options: { timeoutMs?: number; warn?: (message: string) => void } = {}): NotifierRegistry {
  // Providers can register during a backend import after the initial built-ins
  // were created. Include them in the default registry without importing any
  // backend here.
  const defaults = notifiers ?? [
    ...builtinNotifiers,
    ...allSinkProviders()
      .filter((provider) => !builtinNotifiers.some((notifier) => notifier.id === provider.id))
      .map(providerNotifier),
  ];
  return new NotifierRegistry(defaults, options);
}

const notifierRegistry: NotifierRegistry = createNotifierRegistry();
// Providers that register after this module initialized still reach the default registry.
onSinkProviderRegistered((provider) => notifierRegistry.register(providerNotifier(provider)));

export async function deliverToSink(sink: Sink, event: NotifyEvent): Promise<boolean> {
  const configured = entryFromSink(sink);
  // Preserve the direct sink API: it reports the adapter outcome and does not probe first.
  return notifierRegistry.deliverEntry(configured, event, false);
}

/** Queue best-effort sink delivery without delaying or throwing into the caller. */
export function notify(entries: readonly (Sink | NotifierEntry)[], event: NotifyEvent): void {
  notifierRegistry.notify(event, entries);
}
