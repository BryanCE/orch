import { createRequire } from "node:module";
import type { DatabaseSync, SQLInputValue } from "node:sqlite";
import { mkdirSync, rmSync } from "node:fs";
import { join } from "node:path";
import type { TaskOptions, TaskRec, TaskState } from "../queue.ts";
import { isAdapterId, type AdapterId } from "../adapters/adapter.ts";
import { isBackendId, type BackendId } from "../backends/backend.ts";

// One SQLite file per $ORCH_DIR holds the queue, ownership registry, delivery
// outbox, and spawn registry. jsonl remains the human-visible truth channel for
// presence/results/transitions; only this internal state lives here.

/** Stamped into `PRAGMA user_version`. BUMP THIS whenever a table's columns
 *  change: a store carrying any other stamp is reaped and recreated empty. */
const STORE_SCHEMA = 2;

export interface SpawnedRecord {
  /** Primary registry id: the agent's serialized identity key. */
  pane: string;
  ts?: string;
  adapter?: AdapterId;
  model?: string;
  backend?: BackendId;
  /** Identity workspace assigned by the spawning backend. */
  workspace?: string;
  /** Backend-native control handle (herdr/tmux pane id) for close/focus/send-keys. */
  handle?: string;
  /** Mutable display name. NOT identity — renaming it must never change `pane`. */
  name?: string;
  /** Working directory the agent launched in. */
  cwd?: string;
  worktree?: string;
  branch?: string;
  /** Orchestrator ownership token stamped at spawn time. */
  owner?: string;
}

interface StatementLike {
  run(...params: unknown[]): { changes: number };
  all(...params: unknown[]): unknown[];
  get(...params: unknown[]): unknown;
}

interface DatabaseLike {
  exec(sql: string): void;
  query(sql: string): StatementLike;
  close(): void;
}

/** Bind values crossing from orch's untyped statement port into the driver. Callers
 *  build these from row shapes the schema already fixes, so the driver rejects a
 *  genuinely unbindable value at run time rather than this cast hiding it. */
function asSqlInputs(params: readonly unknown[]): SQLInputValue[] {
  return params as SQLInputValue[];
}

class SqliteDatabaseAdapter implements DatabaseLike {
  public constructor(private readonly database: DatabaseSync) {}

  exec(sql: string): void {
    this.database.exec(sql);
  }

  close(): void {
    this.database.close();
  }

  query(sql: string): StatementLike {
    const statement = this.database.prepare(sql);
    return {
      run: (...params) => ({ changes: Number(statement.run(...asSqlInputs(params)).changes) }),
      all: (...params) => statement.all(...asSqlInputs(params)),
      get: (...params) => statement.get(...asSqlInputs(params)),
    };
  }
}

const connections = new Map<string, DatabaseLike>();

const require = createRequire(import.meta.url);

/** A built-in module this runtime provides, or null when it does not ship one. */
function builtinModuleOrNull<Module>(specifier: string): Module | null {
  try {
    return require(specifier) as Module;
  } catch {
    return null;
  }
}

/** node:sqlite is the driver everywhere it exists; bun predates it, so bun:sqlite
 *  is the guarded fallback there (CLAUDE.md Rule 6). Resolved lazily so a runtime
 *  carrying neither fails at first use, with a name, rather than at module load. */
function createDatabase(file: string): DatabaseLike {
  const nodeSqlite = builtinModuleOrNull<{ DatabaseSync: new (file: string) => DatabaseSync }>("node:sqlite");
  if (nodeSqlite) return new SqliteDatabaseAdapter(new nodeSqlite.DatabaseSync(file));
  const bunSqlite = builtinModuleOrNull<{ Database: new (file: string, options: { create: boolean }) => DatabaseLike }>("bun:sqlite");
  if (bunSqlite) return new bunSqlite.Database(file, { create: true });
  throw new Error(`cannot open ${file}: this runtime provides neither node:sqlite nor bun:sqlite`);
}

function databasePath(orchDir: string): string {
  return join(orchDir, "orch.db");
}

function createTables(db: DatabaseLike): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS queue (
      id TEXT PRIMARY KEY,
      text TEXT NOT NULL,
      opts TEXT NOT NULL,
      origin_workspace TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      state TEXT NOT NULL,
      retries INTEGER NOT NULL DEFAULT 0,
      last_error TEXT,
      agent_key TEXT,
      result TEXT
    );
    CREATE TABLE IF NOT EXISTS ownership (
      agent_key TEXT PRIMARY KEY,
      owner TEXT NOT NULL,
      workspace TEXT,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS outbox (
      id TEXT PRIMARY KEY,
      target TEXT NOT NULL,
      payload TEXT NOT NULL,
      state TEXT NOT NULL,
      attempts INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      next_attempt_at INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS spawned (
      pane TEXT PRIMARY KEY,
      ts TEXT,
      adapter TEXT,
      model TEXT,
      backend TEXT,
      workspace TEXT,
      handle TEXT,
      name TEXT,
      cwd TEXT,
      worktree TEXT,
      branch TEXT
    );
  `);
}

/** True once any table exists — a file this open just created has none, and an
 *  unstamped empty file is new, not stale. */
function storeIsPopulated(db: DatabaseLike): boolean {
  return db.query("SELECT name FROM sqlite_master WHERE type = 'table' LIMIT 1").get() != null;
}

function storeSchemaOf(db: DatabaseLike): number {
  const row = db.query("PRAGMA user_version").get() as { user_version?: number } | null;
  return row?.user_version ?? 0;
}

/**
 * Reap a store written against a different shape and hand back an empty one.
 *
 * `CREATE TABLE IF NOT EXISTS` cannot add a column, so a store from an older
 * shape survives every open and then rejects each insert against the new
 * columns — which spawned panes that no row ever described. Pre-publish there is
 * exactly one shape (Rule 8): the old file is malformed data, not a version to
 * migrate.
 */
function recreateStore(db: DatabaseLike, path: string): DatabaseLike {
  db.close();
  for (const suffix of ["", "-wal", "-shm"]) rmSync(`${path}${suffix}`, { force: true });
  process.stderr.write(`orch: ${path} was written against an older store shape — recreated empty\n`);
  return createDatabase(path);
}

/** Open (create-if-absent) the WAL store for one orch dir; connection is cached. */
function openStore(orchDir: string): DatabaseLike {
  const path = databasePath(orchDir);
  const cached = connections.get(path);
  if (cached) return cached;
  mkdirSync(orchDir, { recursive: true });
  let db = createDatabase(path);
  if (storeIsPopulated(db) && storeSchemaOf(db) !== STORE_SCHEMA) db = recreateStore(db, path);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA busy_timeout = 5000;");
  createTables(db);
  db.exec(`PRAGMA user_version = ${STORE_SCHEMA}`);
  connections.set(path, db);
  return db;
}

/** Close every cached connection; tests call this before removing their temp dirs. */
export function closeAllStores(): void {
  for (const [path, db] of connections) {
    db.close();
    connections.delete(path);
  }
}

interface QueueRow {
  id: string;
  text: string;
  opts: string;
  origin_workspace: string | null;
  created_at: string;
  updated_at: string;
  state: string;
  retries: number;
  last_error: string | null;
  agent_key: string | null;
  result: string | null;
}

function rowToTask(row: QueueRow): TaskRec {
  const task: TaskRec = {
    id: row.id,
    text: row.text,
    opts: JSON.parse(row.opts) as TaskOptions,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    state: row.state as TaskState,
    retries: row.retries,
  };
  if (row.origin_workspace !== null) task.workspace = row.origin_workspace;
  if (row.last_error !== null) task.lastError = row.last_error;
  if (row.agent_key !== null) task.agentKey = row.agent_key;
  if (row.result !== null) task.result = JSON.parse(row.result) as unknown;
  return task;
}

export function insertQueueTask(orchDir: string, task: TaskRec): void {
  openStore(orchDir)
    .query(
      `INSERT INTO queue (id, text, opts, origin_workspace, created_at, updated_at, state, retries)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      task.id,
      task.text,
      JSON.stringify(task.opts),
      task.workspace ?? null,
      task.createdAt,
      task.updatedAt,
      task.state,
      task.retries,
    );
}

export function selectQueueTasks(orchDir: string): TaskRec[] {
  const rows = openStore(orchDir).query("SELECT * FROM queue ORDER BY created_at ASC").all() as QueueRow[];
  return rows.map(rowToTask);
}

/** Record which orchestrator controls an agent, replacing any prior owner. */
export function setOwner(orchDir: string, agentKey: string, owner: string): void {
  const updatedAt = new Date().toISOString();
  openStore(orchDir)
    .query(
      `INSERT INTO ownership (agent_key, owner, updated_at)
       VALUES (?, ?, ?)
       ON CONFLICT(agent_key) DO UPDATE SET owner = excluded.owner, updated_at = excluded.updated_at`,
    )
    .run(agentKey, owner, updatedAt);
}

export function getOwner(orchDir: string, agentKey: string): string | undefined {
  const row = openStore(orchDir)
    .query("SELECT owner FROM ownership WHERE agent_key = ?")
    .get(agentKey) as { owner: string } | null;
  return row?.owner;
}

export type OwnerWriteResult =
  | { ok: true; reassigned?: boolean }
  | { ok: false; reason: string };

/** Check ownership synchronously and optionally transfer control to the actor. */
export function checkOwnerWrite(
  orchDir: string,
  agentKey: string,
  actor: string,
  opts: { steal?: boolean } = {},
): OwnerWriteResult {
  const owner = getOwner(orchDir, agentKey);
  if (owner === undefined || owner === actor) return { ok: true };
  if (!opts.steal) return { ok: false, reason: `agent is owned by ${owner}` };
  const changes = openStore(orchDir)
    .query("UPDATE ownership SET owner = ?, updated_at = ? WHERE agent_key = ? AND owner = ?")
    .run(actor, new Date().toISOString(), agentKey, owner).changes;
  if (changes === 1) return { ok: true, reassigned: true };
  const current = getOwner(orchDir, agentKey);
  return { ok: false, reason: `agent is owned by ${current ?? owner}` };
}

export function selectQueueTask(orchDir: string, id: string): TaskRec | undefined {
  const row = openStore(orchDir).query("SELECT * FROM queue WHERE id = ?").get(id) as QueueRow | null;
  return row ? rowToTask(row) : undefined;
}

/** Atomic queued->claimed transition; true only for the single winning caller. */
export function writeTaskClaim(orchDir: string, id: string, agentKey: string, ts: string): boolean {
  const changes = openStore(orchDir)
    .query("UPDATE queue SET state = 'claimed', agent_key = ?, updated_at = ? WHERE id = ? AND state = 'queued'")
    .run(agentKey, ts, id).changes;
  return changes === 1;
}

export function writeTaskDone(orchDir: string, id: string, ts: string, result: unknown): void {
  openStore(orchDir)
    .query("UPDATE queue SET state = 'done', result = ?, updated_at = ? WHERE id = ? AND state = 'claimed'")
    .run(result === undefined ? null : JSON.stringify(result), ts, id);
}

export function writeTaskFailure(orchDir: string, id: string, ts: string, error: string): void {
  openStore(orchDir)
    .query("UPDATE queue SET state = 'failed', last_error = ?, updated_at = ? WHERE id = ? AND state = 'claimed'")
    .run(error, ts, id);
}

export function writeTaskRequeue(orchDir: string, id: string, ts: string, error?: string): void {
  const db = openStore(orchDir);
  if (error === undefined) {
    db.query(
      "UPDATE queue SET state = 'queued', retries = retries + 1, updated_at = ? WHERE id = ? AND state IN ('claimed', 'failed')",
    ).run(ts, id);
    return;
  }
  db.query(
    "UPDATE queue SET state = 'queued', retries = retries + 1, last_error = ?, updated_at = ? WHERE id = ? AND state IN ('claimed', 'failed')",
  ).run(error, ts, id);
}

export function writeTaskCancel(orchDir: string, id: string, ts: string): void {
  openStore(orchDir)
    .query("UPDATE queue SET state = 'cancelled', updated_at = ? WHERE id = ? AND state = 'queued'")
    .run(ts, id);
}

interface SpawnedRow {
  pane: string;
  ts: string | null;
  adapter: string | null;
  model: string | null;
  backend: string | null;
  workspace: string | null;
  handle: string | null;
  name: string | null;
  cwd: string | null;
  worktree: string | null;
  branch: string | null;
}

function rowToSpawned(row: SpawnedRow): SpawnedRecord {
  const record: SpawnedRecord = { pane: row.pane };
  if (row.ts !== null) record.ts = row.ts;
  // A row naming a provider this orch does not ship is malformed, not a version
  // to support (Rule 8): drop the field so callers take their unknown-provider path.
  if (isAdapterId(row.adapter)) record.adapter = row.adapter;
  if (row.model !== null) record.model = row.model;
  if (isBackendId(row.backend)) record.backend = row.backend;
  if (row.workspace !== null) record.workspace = row.workspace;
  if (row.handle !== null) record.handle = row.handle;
  if (row.name !== null) record.name = row.name;
  if (row.cwd !== null) record.cwd = row.cwd;
  if (row.worktree !== null) record.worktree = row.worktree;
  if (row.branch !== null) record.branch = row.branch;
  return record;
}

/** Upsert by pane: a later spawn of the same pane replaces the earlier record. */
export function insertSpawnedRecord(orchDir: string, record: SpawnedRecord): void {
  openStore(orchDir)
    .query(
      `INSERT INTO spawned (pane, ts, adapter, model, backend, workspace, handle, name, cwd, worktree, branch)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(pane) DO UPDATE SET
         ts = excluded.ts, adapter = excluded.adapter, model = excluded.model,
         backend = excluded.backend, workspace = excluded.workspace, handle = excluded.handle,
         name = excluded.name, cwd = excluded.cwd,
         worktree = excluded.worktree, branch = excluded.branch`,
    )
    .run(
      record.pane,
      record.ts ?? null,
      record.adapter ?? null,
      record.model ?? null,
      record.backend ?? null,
      record.workspace ?? null,
      record.handle ?? null,
      record.name ?? null,
      record.cwd ?? null,
      record.worktree ?? null,
      record.branch ?? null,
    );
}

export function selectSpawnedRecords(orchDir: string): SpawnedRecord[] {
  const rows = openStore(orchDir).query("SELECT * FROM spawned").all() as SpawnedRow[];
  return rows.map((row) => {
    const record = rowToSpawned(row);
    const owner = getOwner(orchDir, record.pane);
    if (owner !== undefined) record.owner = owner;
    return record;
  });
}

/** Relabel an agent. The name is a mutable column; the key it sits beside is not. */
export function writeSpawnedName(orchDir: string, pane: string, name: string): boolean {
  return openStore(orchDir).query("UPDATE spawned SET name = ? WHERE pane = ?").run(name, pane).changes === 1;
}

export function deleteSpawnedRecord(orchDir: string, pane: string): void {
  openStore(orchDir).query("DELETE FROM spawned WHERE pane = ?").run(pane);
}

export interface OutboxMessageInput {
  id: string;
  target: string;
  payload: unknown;
  createdAt?: string;
}

export interface OutboxMessage {
  id: string;
  target: string;
  payload: unknown;
  state: "pending" | "delivered";
  attempts: number;
  createdAt: string;
  nextAttemptAt: number;
}

interface OutboxRow {
  id: string;
  target: string;
  payload: string;
  state: string;
  attempts: number;
  created_at: string;
  next_attempt_at: number;
}

function rowToOutboxMessage(row: OutboxRow): OutboxMessage {
  return {
    id: row.id,
    target: row.target,
    payload: JSON.parse(row.payload) as unknown,
    state: row.state as OutboxMessage["state"],
    attempts: row.attempts,
    createdAt: row.created_at,
    nextAttemptAt: row.next_attempt_at,
  };
}

/** Insert a pending message; synchronous so callers may use it in a transaction. */
export function insertOutboxMessage(orchDir: string, msg: OutboxMessageInput): void {
  const createdAt = msg.createdAt ?? new Date().toISOString();
  openStore(orchDir)
    .query(
      `INSERT INTO outbox (id, target, payload, state, attempts, created_at, updated_at, next_attempt_at)
       VALUES (?, ?, ?, 'pending', 0, ?, ?, 0)`,
    )
    .run(msg.id, msg.target, JSON.stringify(msg.payload), createdAt, createdAt);
}

export function selectPendingOutbox(orchDir: string, now: number): OutboxMessage[] {
  const rows = openStore(orchDir)
    .query(
      "SELECT id, target, payload, state, attempts, created_at, next_attempt_at FROM outbox WHERE state = 'pending' AND next_attempt_at <= ? ORDER BY created_at ASC",
    )
    .all(now) as OutboxRow[];
  return rows.map(rowToOutboxMessage);
}

export function markOutboxDelivered(orchDir: string, id: string): void {
  openStore(orchDir)
    .query("UPDATE outbox SET state = 'delivered' WHERE id = ? AND state = 'pending'")
    .run(id);
}

export function bumpOutboxAttempt(orchDir: string, id: string, nextAttemptAt: number): void {
  openStore(orchDir)
    .query(
      "UPDATE outbox SET attempts = attempts + 1, next_attempt_at = ? WHERE id = ? AND state = 'pending'",
    )
    .run(nextAttemptAt, id);
}
